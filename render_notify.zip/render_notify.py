bl_info = {
    "name": "Render Notify",
    "blender": (4, 5, 0),
    "category": "Render",
    "version": (1, 1),
    "author": "ChatGPT",
    "description": "Sends a Windows toast notification when a render is complete, with optional custom sound."
}

import bpy
import subprocess
import os

class RenderNotifyPreferences(bpy.types.AddonPreferences):
    bl_idname = __name__

    custom_sound: bpy.props.StringProperty(
        name="Custom Sound",
        subtype="FILE_PATH",
        description="Optional custom sound to play after render is done"
    )
    play_sound: bpy.props.BoolProperty(
        name="Play Sound",
        default=True,
        description="Play a sound after render completes"
    )

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "play_sound")
        layout.prop(self, "custom_sound")

def notify_windows(title, message, sound_path=None):
    script = (
        "[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] > $null;"
        "$template = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent([Windows.UI.Notifications.ToastTemplateType]::ToastText02);"
        "$textNodes = $template.GetElementsByTagName('text');"
        f"$textNodes[0].AppendChild($template.CreateTextNode('{title}')) > $null;"
        f"$textNodes[1].AppendChild($template.CreateTextNode('{message}')) > $null;"
        "$xml = New-Object Windows.Data.Xml.Dom.XmlDocument;"
        "$xml.LoadXml($template.GetXml());"
        "$toast = [Windows.UI.Notifications.ToastNotification]::new($xml);"
        "$notifier = [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier('Blender Render Notify');"
        "$notifier.Show($toast);"
    )
    subprocess.Popen(["powershell", "-Command", script], shell=True)

    if sound_path and os.path.isfile(sound_path):
        try:
            import winsound
            winsound.PlaySound(sound_path, winsound.SND_FILENAME | winsound.SND_ASYNC)
        except Exception as e:
            print("Could not play custom sound:", e)
    else:
        try:
            import winsound
            winsound.MessageBeep()
        except:
            pass

def render_complete_handler(scene, depsgraph):
    prefs = bpy.context.preferences.addons[__name__].preferences
    panel_settings = bpy.context.window_manager.render_notify_settings
    sound = prefs.custom_sound if prefs.play_sound else None
    if panel_settings.enable_notification:
        notify_windows("Blender Render Complete", f"Render of {scene.name} finished.", sound)

class RenderNotifySettings(bpy.types.PropertyGroup):
    enable_notification: bpy.props.BoolProperty(
        name="Enable Notification",
        default=True,
        description="Show a Windows toast notification after render completes"
    )

class RENDERNOTIFY_PT_panel(bpy.types.Panel):
    bl_label = "Render Notify"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Render Notify"

    def draw(self, context):
        prefs = bpy.context.preferences.addons[__name__].preferences
        wm = context.window_manager
        layout = self.layout
        layout.prop(wm.render_notify_settings, "enable_notification")
        layout.prop(prefs, "play_sound")
        layout.prop(prefs, "custom_sound")

classes = (
    RenderNotifyPreferences,
    RenderNotifySettings,
    RENDERNOTIFY_PT_panel,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.WindowManager.render_notify_settings = bpy.props.PointerProperty(type=RenderNotifySettings)
    bpy.app.handlers.render_complete.append(render_complete_handler)

def unregister():
    if render_complete_handler in bpy.app.handlers.render_complete:
        bpy.app.handlers.render_complete.remove(render_complete_handler)
    del bpy.types.WindowManager.render_notify_settings
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()
