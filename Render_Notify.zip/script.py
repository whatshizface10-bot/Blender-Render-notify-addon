bl_info = {
    "name": "Render Notify",
    "blender": (4, 5, 0),
    "category": "Render",
    "version": (1, 3),
    "author": "Whats hizface (with some AI assistance)",
    "description": "Sends a Windows toast notification when a render is complete, with optional custom sound. Also shows improved ETA in the render window."
}

import bpy
import time
import subprocess
import os

# GitHub repository releases page
GITHUB_RELEASES_URL = "https://github.com/whatshizface10-bot/Blender-Render-notify-addon/releases"

# Track render timing
render_start_time = None
frame_times = []


def format_time(seconds: float) -> str:
    """Convert seconds to H:MM:SS string."""
    seconds = int(seconds)
    h, m = divmod(seconds, 3600)
    m, s = divmod(m, 60)
    if h > 0:
        return f"{h:d}:{m:02d}:{s:02d}"
    else:
        return f"{m:02d}:{s:02d}"


class RenderNotifyPreferences(bpy.types.AddonPreferences):
    bl_idname = __name__

    custom_sound: bpy.props.StringProperty(
        name="Custom Sound",
        subtype="FILE_PATH",
        description="Optional custom sound to play after render is done"
    )
    play_sound: bpy.props.BoolProperty(
        name="Play Sound",
        default=True,
        description="Play a sound after render completes"
    )

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "play_sound")
        layout.prop(self, "custom_sound")


def notify_windows(title, message, sound_path=None):
    script = (
        "[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] > $null;"
        "$template = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent([Windows.UI.Notifications.ToastTemplateType]::ToastText02);"
        "$textNodes = $template.GetElementsByTagName('text');"
        f"$textNodes[0].AppendChild($template.CreateTextNode('{title}')) > $null;"
        f"$textNodes[1].AppendChild($template.CreateTextNode('{message}')) > $null;"
        "$xml = New-Object Windows.Data.Xml.Dom.XmlDocument;"
        "$xml.LoadXml($template.GetXml());"
        "$toast = [Windows.UI.Notifications.ToastNotification]::new($xml);"
        "$notifier = [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier('Blender Render Notify');"
        "$notifier.Show($toast);"
    )
    subprocess.Popen(["powershell", "-Command", script], shell=True)

    if sound_path and os.path.isfile(sound_path):
        try:
            import winsound
            winsound.PlaySound(sound_path, winsound.SND_FILENAME | winsound.SND_ASYNC)
        except Exception as e:
            print("Could not play custom sound:", e)
    else:
        try:
            import winsound
            winsound.MessageBeep()
        except:
            pass


# -------------------------------
# Render Handlers for Timing
# -------------------------------

def render_init_handler(scene):
    global render_start_time, frame_times
    render_start_time = time.time()
    frame_times = []


def render_complete_handler(scene, depsgraph):
    prefs = bpy.context.preferences.addons[__name__].preferences
    panel_settings = bpy.context.window_manager.render_notify_settings
    sound = prefs.custom_sound if prefs.play_sound else None
    if panel_settings.enable_notification:
        notify_windows("Blender Render Complete", f"Render of {scene.name} finished.", sound)


def render_frame_handler(scene):
    global render_start_time, frame_times
    if render_start_time:
        frame_times.append(time.time() - render_start_time)
        render_start_time = time.time()


# -------------------------------
# UI Elements
# -------------------------------

class RenderNotifySettings(bpy.types.PropertyGroup):
    enable_notification: bpy.props.BoolProperty(
        name="Enable Notification",
        default=True,
        description="Show a Windows toast notification after render completes"
    )
    updates_expanded: bpy.props.BoolProperty(
        name="Updates",
        default=False,
        description="Show/hide updates section"
    )


class RENDERNOTIFY_PT_panel(bpy.types.Panel):
    bl_label = "Render Notify"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Render Notify"

    def draw(self, context):
        prefs = bpy.context.preferences.addons[__name__].preferences
        wm = context.window_manager
        layout = self.layout

        # Notification options
        layout.prop(wm.render_notify_settings, "enable_notification")
        if wm.render_notify_settings.enable_notification:
            layout.prop(prefs, "play_sound")
            if prefs.play_sound:
                layout.prop(prefs, "custom_sound")

        layout.separator()

        # Collapsible Updates section
        layout.prop(
            wm.render_notify_settings,
            "updates_expanded",
            icon="TRIA_DOWN" if wm.render_notify_settings.updates_expanded else "TRIA_RIGHT",
            emboss=False
        )

        if wm.render_notify_settings.updates_expanded:
            box = layout.box()
            version_str = ".".join(str(v) for v in bl_info["version"])
            box.label(text=f"Current Version: {version_str}")
            box.operator("render_notify.open_github", text="Open GitHub Page")


class RENDERNOTIFY_PT_render_status(bpy.types.Panel):
    bl_label = "Render ETA"
    bl_space_type = "IMAGE_EDITOR"
    bl_region_type = "UI"
    bl_category = "Render Notify"

    def draw(self, context):
        global frame_times, render_start_time
        layout = self.layout
        scene = context.scene

        if not render_start_time:
            layout.label(text="No render running.")
            return

        elapsed = time.time() - render_start_time
        layout.label(text=f"Elapsed Time: {format_time(elapsed)}")

        if frame_times:
            avg_time = sum(frame_times) / len(frame_times)
            remaining_frames = (scene.frame_end - scene.frame_current)
            eta = avg_time * remaining_frames
            layout.label(text=f"Estimated Remaining: {format_time(eta)}")
        else:
            layout.label(text="Estimating...")


class RENDERNOTIFY_OT_open_github(bpy.types.Operator):
    bl_idname = "render_notify.open_github"
    bl_label = "Open GitHub Page"

    def execute(self, context):
        bpy.ops.wm.url_open(url=GITHUB_RELEASES_URL)
        return {'FINISHED'}


# -------------------------------
# Registration
# -------------------------------

classes = (
    RenderNotifyPreferences,
    RenderNotifySettings,
    RENDERNOTIFY_PT_panel,
    RENDERNOTIFY_PT_render_status,
    RENDERNOTIFY_OT_open_github,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.WindowManager.render_notify_settings = bpy.props.PointerProperty(type=RenderNotifySettings)
    bpy.app.handlers.render_complete.append(render_complete_handler)
    bpy.app.handlers.render_init.append(render_init_handler)
    bpy.app.handlers.render_write.append(render_frame_handler)


def unregister():
    if render_complete_handler in bpy.app.handlers.render_complete:
        bpy.app.handlers.render_complete.remove(render_complete_handler)
    if render_init_handler in bpy.app.handlers.render_init:
        bpy.app.handlers.render_init.remove(render_init_handler)
    if render_frame_handler in bpy.app.handlers.render_write:
        bpy.app.handlers.render_write.remove(render_frame_handler)

    del bpy.types.WindowManager.render_notify_settings
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
